<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salesdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add cache-control headers to ensure the latest data is loaded
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxie

// Assuming you're connected to the database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $table = $_POST['table']; // FNO, Pricelist, or Package

    if ($table == 'FNO') {
        $name = $_POST['name'];
        $logo = isset($_FILES['logo']) ? $_FILES['logo'] : null;
        
        if ($logo) {
            $target = "uploads/" . basename($logo['name']);
            move_uploaded_file($logo['tmp_name'], $target);
            $logoPath = $target;
        }

        $sql = "UPDATE FNO SET FNO_Name = ?, FNO_Logo = ? WHERE FNO_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $name, $logoPath, $id);
        $stmt->execute();

    } elseif ($table == 'Pricelist') {
        $shortDesc = $_POST['shortDesc'];
        $longDesc = $_POST['longDesc'];
        $sql = "UPDATE Pricelist SET PR_Short_Description = ?, PR_Long_Description = ? WHERE PR_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $shortDesc, $longDesc, $id);
        $stmt->execute();

    } elseif ($table == 'Package') {
        $term = $_POST['term'];
        $speed = $_POST['speed'];
        $price = $_POST['price'];
        $sql = "UPDATE Package SET PK_Term = ?, PK_Speed = ?, PK_Price = ? WHERE PK_ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdi", $term, $speed, $price, $id);
        $stmt->execute();
    }

    echo "Data updated successfully!";
}
?>