# Venchi--AdminDashboard

## Introduction

>Vanchi is a Material unique admin template built with tiles concept. It comes with Different Colorful dashboard , fully responsive HTML pages and, colorful widgets<br>

#features & Pages:

✔Login<br> 
✔Dahboard<br> 
✔Admin<br> 
✔Tenant<br> 
✔Flat<br>
✔Utlity<br> 
✔UserProfile<br>




#�Main features:

✔HTML5 & CSS3<br> 
✔Simple Dashboard Design<br> 
✔Responsive Design<br> 
✔User Friendly Code<br> 
✔Clean Markup<br> 
✔Colorful Design<br> 
✔Cross Browser Support<br> 
✔Material UI<br> 
✔Used font awesome icon<br> 



