<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salesdb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $tc_id = $_GET['id'];
    $query = "DELETE FROM tandc WHERE TC_id = '$tc_id'";

    if (mysqli_query($conn, $query)) {
        $_SESSION['success_msg'] = "Terms & Conditions deleted successfully!";
    } else {
        $_SESSION['error_msg'] = "Error deleting Terms & Conditions.";
    }
}

header("view_pricelist.php");
exit();
?>
