<?php
var_dump($_POST);  // This will show you the submitted form data
?>
