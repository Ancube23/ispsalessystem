<?php
require('fpdf186/fpdf.php');
require('src/autoload.php');
require('src/FPDI.php');

use setasign\Fpdi\Fpdi;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salesdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get selected Pricelist
if (!isset($_GET['pricelist'])) {
    die("Invalid request");
}
$pricelist = $_GET['pricelist'];

// Fetch Pricelist ID
$pricelist_query = mysqli_query($conn, "SELECT PR_id FROM Pricelist WHERE PR_Short_Description = '$pricelist'");
$pricelist_data = mysqli_fetch_assoc($pricelist_query);
$pricelist_id = $pricelist_data['PR_id'] ?? null;

if (!$pricelist_id) {
    die("Pricelist not found.");
}

// Fetch Terms & Conditions for the selected Pricelist
$terms_query = mysqli_query($conn, "SELECT Terms FROM tandc WHERE PR_id = '$pricelist_id'");
$terms_data = mysqli_fetch_assoc($terms_query);
$terms_text = $terms_data['Terms'] ?? "No terms and conditions available.";

// Check if there are any rows
if (mysqli_num_rows($terms_query) > 0) {
    $terms_text = "";
    while ($terms_data = mysqli_fetch_assoc($terms_query)) {
        // Append each term to the $terms_text variable
        $terms_text .= $terms_data['Terms'] . "\n\n";
    }
} else {
    $terms_text = "Debug: No terms and conditions found.";
}

// Fetch all FNOs linked to the selected Pricelist
$fno_result = mysqli_query($conn, "SELECT DISTINCT f.* FROM FNO f
    JOIN Package p ON f.FNO_id = p.FNO_id
    WHERE p.PR_id = '$pricelist_id'
    ORDER BY f.FNO_Name ASC");

// Fetch the cover page for the selected Pricelist
$cover_query = mysqli_query($conn, "SELECT CP_FilePath FROM cover_page WHERE PR_id = '$pricelist_id'");
$cover_data = mysqli_fetch_assoc($cover_query);
$cover_path = $cover_data['CP_FilePath'] ?? null;

// Initialize FPDI (not FPDF directly)
$pdf = new FPDI();
$pdf->SetAutoPageBreak(true, 20);

// First Page - Cover Page
if ($cover_path && file_exists($cover_path)) {
    $file_extension = pathinfo($cover_path, PATHINFO_EXTENSION);
    $pdf->AddPage();

    if ($file_extension == 'pdf') {
        // If the cover page is a PDF, import the first page
        $pdf->setSourceFile($cover_path);
        $template = $pdf->importPage(1);
        $pdf->useTemplate($template, 0, 0, $pdf->GetPageWidth(), $pdf->GetPageHeight());
    } elseif ($file_extension == 'docx') {
        // If the cover page is a Word document, convert it to PDF format
        $phpWord = IOFactory::load($cover_path);
        $xmlWriter = IOFactory::createWriter($phpWord, 'PDF');
        $temp_pdf = tempnam(sys_get_temp_dir(), 'cover_page_') . '.pdf';
        $xmlWriter->save($temp_pdf);
        
        $pdf->Image($temp_pdf, 0, 0, $pdf->GetPageWidth(), $pdf->GetPageHeight());
        unlink($temp_pdf); // Clean up the temporary file
    }
    $pdf->Ln(10); // Space before next page
}

// First Page - Terms & Conditions
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, "Terms & Conditions", 0, 1, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 8, $terms_text);
$pdf->Ln(10); // Space before next page

// Add a new page for the pricelist
$pdf->AddPage();

// Add Pricelist Title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, "$pricelist Packages", 0, 1, 'C');
$pdf->Ln(5);

// Loop through each FNO
while ($fno = mysqli_fetch_assoc($fno_result)) {
    $fno_id = $fno['FNO_id'];

    // Fetch packages for this FNO
    $package_result = mysqli_query($conn, "SELECT * FROM Package WHERE FNO_id = '$fno_id' AND PR_id = '$pricelist_id'");

    // Display FNO logo and name
    if (!empty($fno['FNO_Logo']) && file_exists($fno['FNO_Logo'])) {
        $pdf->Image($fno['FNO_Logo'], ($pdf->GetPageWidth() - 50) / 2, $pdf->GetY(), 50);
    }
    $pdf->Ln(20); // Space after logo
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, $fno['FNO_Name'], 0, 1, 'C');
    $pdf->Ln(5);

    // Table Header
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetFillColor(200, 200, 200);
    $tableWidth = 150;
    $xStart = ($pdf->GetPageWidth() - $tableWidth) / 2;

    $pdf->SetX($xStart);
    $pdf->Cell(50, 10, 'Term', 1, 0, 'C', true);
    $pdf->Cell(50, 10, 'Speed (Mbps)', 1, 0, 'C', true);
    $pdf->Cell(50, 10, 'Price (R pm)', 1, 1, 'C', true);

    // Table Content
    $pdf->SetFont('Arial', '', 12);
    while ($package = mysqli_fetch_assoc($package_result)) {
        $pdf->SetX($xStart);
        $pdf->Cell(50, 10, $package['PK_Term'], 1, 0, 'C');
        $pdf->Cell(50, 10, $package['PK_Speed'], 1, 0, 'C');
        $pdf->Cell(50, 10, 'R ' . number_format($package['PK_Price'], 2) . ' pm', 1, 1, 'C');
    }

    $pdf->Ln(10);
}

// Output PDF in browser
$pdf->Output('I', "{$pricelist}_Pricelist.pdf");

?>
