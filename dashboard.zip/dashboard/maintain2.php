<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salesdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle FNO submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_fno'])) {
    $fno_name = $_POST['fno_name'];
    $fno_logo = $_FILES['fno_logo']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($fno_logo);

    move_uploaded_file($_FILES['fno_logo']['tmp_name'], $target_file);

    $query = "INSERT INTO FNO (FNO_Name, FNO_Logo) VALUES ('$fno_name', '$target_file')";
    mysqli_query($conn, $query);

    $_SESSION['success_msg'] = "FNO added successfully!";
}

// Handle Pricelist submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_pricelist'])) {
    $pr_fno_id = $_POST['pr_fno_id'];
    $pr_short = $_POST['pr_short'];
    $pr_long = $_POST['pr_long'];

    if (!empty($pr_fno_id)) {
        $query = "INSERT INTO Pricelist (PR_Short_Description, PR_Long_Description, PR_FNO_id) 
                  VALUES ('$pr_short', '$pr_long', '$pr_fno_id')";
        mysqli_query($conn, $query);

        $_SESSION['success_msg'] = "Pricelist added successfully!";
    } else {
        $_SESSION['error_msg'] = "Error: No FNO selected or invalid ID.";
    }
}

// Handle Package submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_package'])) {
    $fno_id = $_POST['fno_id'];
    $pr_id = $_POST['pr_id'];
    $pk_term = $_POST['pk_term'];
    $pk_speed = $_POST['pk_speed'];
    $pk_price = $_POST['pk_price'];
    
    $query = "INSERT INTO Package (PR_id, FNO_id, PK_Term, PK_Speed, PK_Price) 
              VALUES ('$pr_id', '$fno_id', '$pk_term', '$pk_speed', '$pk_price')";
    mysqli_query($conn, $query);

    $_SESSION['success_msg'] = "Package added successfully!";
}

// Handle Terms & Conditions submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_terms'])) {
    $pr_id = $_POST['pr_id'];
    $terms = mysqli_real_escape_string($conn, $_POST['terms']);

    $query = "INSERT INTO tandc (PR_id, Terms) VALUES ('$pr_id', '$terms')";
    if (mysqli_query($conn, $query)) {
        $_SESSION['success_msg'] = "Terms & Conditions added successfully!";
    } else {
        $_SESSION['error_msg'] = "Error adding Terms & Conditions.";
    }
}



// Fetch existing FNOs, Terms, and Pricelists
$fno_result = mysqli_query($conn, "SELECT * FROM FNO ORDER BY FNO_Name ASC");
$term_result = mysqli_query($conn, "SELECT * FROM Term ORDER BY T_name ASC");
$pricelist_result = mysqli_query($conn, "SELECT * FROM Pricelist ORDER BY PR_Short_Description ASC");

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['cover_page'])) {
    // Get the Pricelist ID from the form
    $pricelist_id = $_POST['pricelist'];

    // Handle file upload
    $target_dir = "uploads/cover_pages/";
    $target_file = $target_dir . basename($_FILES["cover_page"]["name"]);
    $uploadOk = 1;
    $fileExtension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if the uploaded file is either a PDF or Word document
    $allowedExtensions = ['pdf', 'doc', 'docx'];

    if (!in_array($fileExtension, $allowedExtensions)) {
        echo "Sorry, only PDF, DOC, DOCX files are allowed.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["cover_page"]["size"] > 5000000) { // 5MB limit
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Check if upload is okay
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["cover_page"]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES["cover_page"]["name"])) . " has been uploaded.";

            // Save the file path in the database
            $query = "INSERT INTO cover_page (PR_id, CP_FilePath) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("is", $pricelist_id, $target_file);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintain Pricelist</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

   <?php if (isset($_SESSION['success_msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['success_msg']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['success_msg']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error_msg'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error_msg']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['error_msg']); ?>
<?php endif; ?>



    <div class="container mt-5">
        <h2 class="text-center">Maintain Pricelist</h2>

        <!-- ADD NEW FNO FORM -->
        <form method="POST" enctype="multipart/form-data" class="card p-4 shadow mb-3">
            <h5>Add Fibre Network Operator</h5>
            <div class="mb-3">
                <label class="form-label">FNO Name</label>
                <input type="text" name="fno_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">FNO Logo</label>
                <input type="file" name="fno_logo" class="form-control" required>
            </div>
            <button type="submit" name="submit_fno" class="btn btn-success">Add FNO</button>
        </form>

        <!-- ADD NEW PRICELIST FORM -->
<form method="POST" class="card p-4 shadow mb-3">
    <h5>Add Pricelist</h5>

    <div class="mb-3">
        <label class="form-label">Fibre Network Operator</label>
        <select name="pr_fno_id" class="form-control" required>
            <option value="">Select FNO</option>
            <?php 
            $fno_result = mysqli_query($conn, "SELECT * FROM FNO ORDER BY FNO_Name ASC");
            while ($row = mysqli_fetch_assoc($fno_result)) { ?>
                <option value="<?php echo $row['FNO_id']; ?>"><?php echo $row['FNO_Name']; ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Short Description</label>
        <input type="text" name="pr_short" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Long Description</label>
        <textarea name="pr_long" class="form-control" required></textarea>
    </div>

    <button type="submit" name="submit_pricelist" class="btn btn-success">Add Pricelist</button>
</form>




        <!-- ADD PACKAGE FORM -->
        <form method="POST" class="card p-4 shadow">
    <h5>Add Package</h5>

    <div class="mb-3">
        <label class="form-label">Fibre Network Operator</label>
        <select name="fno_id" class="form-control" required>
            <option value="">Select FNO</option>
            <?php 
            $fno_result = mysqli_query($conn, "SELECT * FROM FNO ORDER BY FNO_Name ASC");
            while ($row = mysqli_fetch_assoc($fno_result)) { ?>
                <option value="<?php echo $row['FNO_id']; ?>"><?php echo $row['FNO_Name']; ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Pricelist</label>
        <select name="pr_id" class="form-control" required>
            <option value="">Select Pricelist</option>
            <?php while ($row = mysqli_fetch_assoc($pricelist_result)) { ?>
                <option value="<?php echo $row['PR_id']; ?>"><?php echo $row['PR_Short_Description']; ?></option>
            <?php } ?>
        </select>
    </div>

    <!-- Bootstrap-styled radio buttons for Term -->
    <div class="mb-3">
        <label class="form-label d-block">Term</label>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="pk_term" id="monthToMonth" value="Month-to-Month" required>
            <label class="form-check-label" for="monthToMonth">Month-to-Month</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="pk_term" id="twelveMonths" value="12 Months" required>
            <label class="form-check-label" for="twelveMonths">12 Months</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="pk_term" id="twentyFourMonths" value="24 Months" required>
            <label class="form-check-label" for="twentyFourMonths">24 Months</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="pk_term" id="thirtySixMonths" value="36 Months" required>
            <label class="form-check-label" for="thirtySixMonths">36 Months</label>
        </div>
    </div>

    <div class="mb-3">
        <label class="form-label">Speed (Mbps)</label>
        <input type="text" name="pk_speed" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Price (R)</label>
        <input type="text" name="pk_price" class="form-control" required>
    </div>

    <button type="submit" name="submit_package" class="btn btn-primary">Save Package</button>
</form>

<!-- ADD TERMS & CONDITIONS FORM -->
<form method="POST" class="card p-4 shadow mt-4">
    <h5>Add Terms & Conditions</h5>

    <div class="mb-3">
        <label class="form-label">Pricelist Group</label>
        <select name="pr_id" class="form-control" required>
            <option value="">Select Pricelist</option>
            <?php 
            $pricelist_result = mysqli_query($conn, "SELECT * FROM Pricelist ORDER BY PR_Short_Description ASC");
            while ($row = mysqli_fetch_assoc($pricelist_result)) { ?>
                <option value="<?php echo $row['PR_id']; ?>"><?php echo $row['PR_Short_Description']; ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Terms & Conditions</label>
        <textarea name="terms" class="form-control" rows="4" required></textarea>
    </div>

    <button type="submit" name="submit_terms" class="btn btn-success">Add Terms & Conditions</button>
</form>

<!-- Upload Cover Page File -->
<form method="POST" enctype="multipart/form-data" class="card p-4 shadow mt-4">
    <h5>Upload Cover Page for Pricelist</h5>

    <!-- Dropdown to select Pricelist -->
    <div class="mb-3">
        <label for="pricelist" class="form-label">Select Pricelist</label>
        <select name="pricelist" id="pricelist" class="form-select" required>
            <option value="" disabled selected>Select Pricelist</option>
            <?php
                // Fetch pricelists from the database
                $query = "SELECT PR_id, PR_Short_Description FROM Pricelist ORDER BY PR_Short_Description ASC";
                $result = mysqli_query($conn, $query);

                // Populate the dropdown with pricelists
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='" . $row['PR_id'] . "'>" . $row['PR_Short_Description'] . "</option>";
                }
            ?>
        </select>
    </div>

    <!-- Upload File for Cover Page -->
    <div class="mb-3">
        <label for="cover_page" class="form-label">Upload Cover Page</label>
        <input type="file" name="cover_page" id="cover_page" class="form-control" required>
    </div>

    <!-- Submit Button -->
    <button type="submit" name="submit" class="btn btn-success">Upload Cover Page</button>
</form>




    </div>

    <!-- Bootstrap Bundle (includes Popper.js for alerts & modals) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


<script>
    document.addEventListener("DOMContentLoaded", function() {
        var alertList = document.querySelectorAll('.alert');
        alertList.forEach(function(alert) {
            new bootstrap.Alert(alert);
        });
    });
</script>

</body>
</html>
